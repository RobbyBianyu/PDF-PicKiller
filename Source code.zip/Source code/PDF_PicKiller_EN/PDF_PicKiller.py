import pikepdf
from pikepdf import PdfImage
import time
import pyfiglet
from colorama import init, Fore
from rich.progress import Progress
from PIL import Image

# Mapping of shading types to English names
shading_type_map = {
    1: "Linear Gradient (Axial)",
    2: "Radial Gradient (Radial)",
    3: "Free-form Gradient (Gouraud)",
    4: "Mesh Gradient (Mesh)",
    5: "PostScript Gradient (Obsolete)"
}


# List XObject images and Shading images in a single page
def list_xobjects_and_shadings(page):
    result = {
        'images': [],  # Each element is (name, width, height)
        'shadings': [],  # Each element is (name, shading_type, coords)
        'watermarks': []  # Each element is (name, resources, bbox)
    }
    try:
        resources = page.obj.get('/Resources')
        if not resources: return result

        shadings = resources.get('/Shading')
        xobjects = resources.get('/XObject')

        # Process XObject images
        if xobjects is not None:
            for name, obj_ref in xobjects.items():
                try:
                    # Safe dereferencing
                    try:
                        obj = obj_ref.get_object()
                    except AttributeError:
                        obj = obj_ref
                    subtype = obj.get('/Subtype')

                    if subtype == '/Image':
                        width = obj.get('/Width', 'Unknown')
                        height = obj.get('/Height', 'Unknown')
                        result['images'].append((name, width, height))

                    elif subtype == '/Form':  # Check if it's a watermark/form
                        form_resources = obj.get('/Resources', 'Unknown')
                        bbox = obj.get('/BBox', 'Unknown')
                        bbox_list = [float(coord) for coord in bbox] if bbox else None
                        result['watermarks'].append((name, form_resources, bbox_list))

                except Exception as e_inner:
                    print(f"⚠️ Oops! Cannot read object {name}: {type(e_inner).__name__}: {e_inner}")
                    continue

        # Process Shading images
        if shadings is not None:
            for name, obj_ref in shadings.items():
                try:
                    # Safe dereferencing
                    try:
                        obj = obj_ref.get_object()
                    except AttributeError:
                        obj = obj_ref
                    shading_type = obj.get('/ShadingType', 'Unknown')
                    coords = obj.get('/Coords', None)
                    coords_list = [float(coord) for coord in coords] if coords else None
                    result['shadings'].append((name, shading_type, coords_list))

                except Exception as e_inner:
                    print(f"⚠️ Oops! Cannot read Shading {name}: {type(e_inner).__name__}: {e_inner}")
                    continue
    except Exception as e:
        print(f"⚠️ Oh no! Error listing XObjects: {type(e).__name__}: {e}")
    return result


# Print XObject images, Shading images, and watermarks for a single page
def print_xobjects_and_shadings(page):
    resources_info = list_xobjects_and_shadings(page)
    images = resources_info['images']
    shadings = resources_info['shadings']
    watermarks = resources_info['watermarks']
    print("🖼️ General Document Images:")
    if images:
        for name, width, height in images:
            print(f"  - Name: {name}, Width: {width}, Height: {height}")
    else:
        print("  - None")
    print("🎨 Gradient Background Images:")
    if shadings:
        for name, shading_type, coords_list in shadings:
            print(
                f"  - Name: {name}, Type: {shading_type}-{shading_type_map.get(shading_type, 'Unknown')}, Coords: {coords_list}")
    else:
        print("  - None")
    print("💧 Watermarks / Form Objects:")
    if watermarks:
        for name, resources, bbox in watermarks:
            resource_type = "Nested Image" if "/Image" in str(resources) else "Pure Text or Vector"
            print(f"  - Name: {name}, Type: {resource_type}, BBox: {bbox}")
    else:
        print("  - None")
    return resources_info


# Delete specified XObject or Shading objects
def remove_targets_from_page(page, targets, resources_info):
    deleted_count = 0
    try:
        resources = page.obj.get('/Resources')
        if not resources: return 0
        xobjects = resources.get('/XObject')
        shadings = resources.get('/Shading')

        if '-a' in targets:
            try:
                if xobjects is not None:
                    for name, _, _ in resources_info.get('images', []):
                        if name in xobjects:
                            del xobjects[name]
                            deleted_count += 1
                    for name, _, _ in resources_info.get('watermarks', []):
                        if name in xobjects:
                            del xobjects[name]
                            deleted_count += 1
                if shadings is not None:
                    for name in list(shadings.keys()):
                        del shadings[name]
                        deleted_count += 1
            except Exception as e_inner:
                print(f"⚠️ Deletion failed: {type(e_inner).__name__}: {e_inner}")
        elif targets:
            for name in targets:
                try:
                    if xobjects is not None and name in xobjects:
                        del xobjects[name]
                        deleted_count += 1
                    elif shadings is not None and name in shadings:
                        del shadings[name]
                        deleted_count += 1
                except Exception as e_inner:
                    print(f"⚠️ Failed to delete {name}: {type(e_inner).__name__}: {e_inner}")
                    continue
    except Exception as e:
        print(f"⚠️ Error reading page resources: {type(e).__name__}: {e}")
    return deleted_count


# Decrypt the PDF file
def decrypt_pdf(input_pdf_path):
    try:
        pdf = pikepdf.open(input_pdf_path)
        page_count = len(pdf.pages)
        if not pdf.is_encrypted:
            pdf.close()
            return input_pdf_path, page_count
        pdf.close()

        pdf = pikepdf.open(input_pdf_path)
        output_file = input_pdf_path.replace('.pdf', '(decrypted).pdf')
        pdf.save(output_file)
        pdf.close()
        print(f"\033[31m✅ Decryption successful, saved as {output_file}\033[0m")
        return output_file, page_count
    except pikepdf.PasswordError:
        print("❌ Cannot decrypt (the encryption might be too advanced~)")
        exit(0)
    except Exception as e:
        print(f"❌ Uh-oh! This is not a PDF file (maybe the path is wrong 🤔): {e}\n\n")
        return "", 0


# Process the PDF file, iterating through each page
def process_pdf(input_path, output_path, targets, resources_info):
    pdf = pikepdf.open(input_path)
    total_deleted_count = 0
    Indirect_page_count = 0
    total_pages = len(pdf.pages)
    start_time = time.time()

    with Progress() as progress:
        task = progress.add_task(f"⏳ Processing progress for {total_pages} pages:", total=total_pages)
        for page_num, page in enumerate(pdf.pages):
            try:
                deleted_count = remove_targets_from_page(page, targets, resources_info)
                total_deleted_count += deleted_count
                if deleted_count == 0:
                    Indirect_page_count += 1
            except Exception as e:
                print(f"Page {page_num + 1} processing failed: {type(e).__name__}: {e}")
            progress.update(task, advance=1)

    elapsed_time = time.time() - start_time
    pdf.save(output_path)
    pdf.close()

    print(f"\n✨ Yay! New file saved as: {output_path}")
    print(f"🥳 Deleted {total_deleted_count} objects in total! ({Indirect_page_count} pages were shared across pages~)")
    print(f"⏱️ Total time elapsed: {elapsed_time:.3f} seconds\n\n")


# Main function
def main():
    while True:
        try:
            while True:
                input_file = input("📚️ Please enter the PDF file path (Enter Q to quit): ").strip()
                if input_file.lower() == 'q':
                    raise KeyboardInterrupt
                if input_file:
                    input_file = input_file.strip('"').strip("'")
                    input_file, page_count = decrypt_pdf(input_file)
                    if page_count: break

            page_num = 1
            with pikepdf.open(input_file) as pdf:
                print("\033[34m🚀 PDF loaded, showing all images on page 1 (template page) by default:\033[0m")
                resources_info = print_xobjects_and_shadings(pdf.pages[0])

            page_num_input = input(
                f"\n\033[32m🎉 Want to change the template page? Enter a page number (2 ~ {page_count}), press Enter to skip, or enter Q to discard current PDF: \033[0m").strip()
            if page_num_input.lower() == 'q':
                print("\n\033[33m🔄 Current operation aborted, starting over!\033[0m\n")
                continue

            if page_num_input:
                try:
                    selected_page = int(page_num_input)
                    if 2 <= selected_page <= page_count:
                        page_num = selected_page
                        with pikepdf.open(input_file) as pdf:
                            print(f"\033[34m🚀 PDF reloaded, showing all images on page {page_num} (template page):\033[0m\n")
                            resources_info = print_xobjects_and_shadings(pdf.pages[page_num - 1])
                    elif selected_page != 1:
                        print(f"\033[32m😬 Whoa! What did you just enter? I'll just ignore that!\033[0m")
                except ValueError:
                    print(f"\033[32m😬 Whoa! What did you just enter? I'll just ignore that!\033[0m")

            while True:
                print("\n\033[35m🧰 Operation Guide:\033[0m")
                print("\033[35m  👉 Preview Image: Enter 'P name' (e.g., P IM23)\033[0m")
                print("\033[35m  🗑️ Delete Object: Enter names (e.g., IM23, wspe_X1), comma-separated. Press Enter directly to delete ALL!\033[0m")
                print("\033[35m  ❌ Abort Operation: Enter Q \033[0m")
                targets_input = input("Please enter your command: ").strip()

                if targets_input.lower() == 'q':
                    print("\n\033[33m🔄 Current operation aborted, starting over!\033[0m\n")
                    break

                # ========== Upgraded Preview Logic ==========
                if targets_input.lower().startswith('p '):
                    target_name = '/' + targets_input[2:].strip()
                    found_preview = False

                    with pikepdf.open(input_file) as pdf:
                        page = pdf.pages[page_num - 1]
                        resources = page.obj.get('/Resources', {})
                        if isinstance(resources, dict) or hasattr(resources, 'get'):
                            xobjects = resources.get('/XObject', {})
                            if xobjects and target_name in xobjects:
                                obj_ref = xobjects[target_name]
                                # Safely get the underlying object
                                obj = obj_ref.get_object() if hasattr(obj_ref, 'get_object') else obj_ref
                                subtype = obj.get('/Subtype')

                                # 1. If it's just a regular image
                                if subtype == '/Image':
                                    try:
                                        print(f"👀 Launching system image viewer to preview {target_name} ...")
                                        pdf_img = PdfImage(obj)
                                        pil_img = pdf_img.as_pil_image()
                                        pil_img.show()
                                        found_preview = True
                                    except Exception as e:
                                        print(f"❌ Preview failed, image format might be special: {e}")

                                # 2. If it's a nested frame (Form), crack it open!
                                elif subtype == '/Form':
                                    print(f"🕵️‍♂️ Detected that {target_name} is a vector frame (Form), trying to crack it open to find inner images...")
                                    form_resources = obj.get('/Resources')
                                    if form_resources:
                                        form_xobjects = form_resources.get('/XObject')
                                        if form_xobjects:
                                            found_inner_image = False
                                            # Iterate through objects inside the frame
                                            for inner_name, inner_obj_ref in form_xobjects.items():
                                                inner_obj = inner_obj_ref.get_object() if hasattr(inner_obj_ref,
                                                                                                  'get_object') else inner_obj_ref
                                                if inner_obj.get('/Subtype') == '/Image':
                                                    try:
                                                        print(f"🖼️ Mystery solved! An image {inner_name} is hiding inside the frame, popping it up now...")
                                                        pdf_img = PdfImage(inner_obj)
                                                        pil_img = pdf_img.as_pil_image()
                                                        pil_img.show()
                                                        found_inner_image = True
                                                        found_preview = True
                                                    except Exception as e:
                                                        print(f"❌ Inner image extraction failed: {e}")

                                            if not found_inner_image:
                                                print(
                                                    "⚠️ Cracked open, but it's full of pure vector code (like formatted text), no pixel images found.")
                                                found_preview = True
                                        else:
                                            print("⚠️ There are no nested image objects in this frame.")
                                            found_preview = True

                    if not found_preview:
                        print(f"🤷‍♂️ Object named {target_name} not found, please check if the name is correct.")

                    continue
                    # ====================================

                # Deletion logic
                output_file = input_file.replace('.pdf', '_removed_images.pdf')
                if targets_input == "":
                    targets = ["-a"]
                    process_pdf(input_file, output_file, targets, resources_info)
                    break
                else:
                    found = False
                    targets = [target.strip() for target in targets_input.split(",")]
                    targets = [f'/{target}' for target in targets]
                    for target in targets:
                        if found: break
                        for category, items in resources_info.items():
                            if found: break
                            for item in items:
                                if target == item[0]:
                                    found = True
                                    break
                    if found:
                        process_pdf(input_file, output_file, targets, resources_info)
                        break
                    else:
                        print("\033[33m🫠 Couldn't find the object you specified, please try again!\033[0m\n")

        except KeyboardInterrupt:
            colors = ["\033[31m", "\033[33m", "\033[32m", "\033[34m", "\033[35m"]
            text = "👋🏻 Program exited. Take care, and see you next time~"
            symbol = "👋🏻 "
            colored_text = symbol + "".join(
                f"{colors[i % len(colors)]}{char}\033[0m" for i, char in enumerate(text[len(symbol):]))
            print(f"\n{colored_text}\n")
            exit(0)


# Run program
if __name__ == "__main__":
    try:
        init()
        welcome_text = pyfiglet.figlet_format("PDF PicKiller", font="starwars", width=90, justify="center")
        print(welcome_text)
        main()
    except Exception as e:
        print(f"An error occurred in the program: {e}")
        time.sleep(10)